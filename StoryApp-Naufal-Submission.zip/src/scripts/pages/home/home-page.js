import HomePresenter from './home-presenter';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix path ikon Leaflet agar kompatibel dengan Webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

export default class HomePage {
  async render() {
    return `
      <main id="main-content" class="home-container" tabindex="-1" role="main">
        <h1 class="page-title">Welcome to the Home Page</h1>
        <div id="map" class="map-container" aria-label="Story locations map" role="region"></div>
        <div id="storyList" class="story-list"></div>
      </main>
    `;
  }

  async afterRender() {
    const storyContainer = document.querySelector('#storyList');
    const mapContainer = document.querySelector('#map');

    if (!storyContainer || !mapContainer) {
      console.error('Element #storyList or #map not found.');
      return;
    }

    const result = await HomePresenter.getStories();

    if (result.error) {
      storyContainer.innerHTML = `<p>${result.message}</p>`;
      return;
    }

    const stories = result.listStory;

    if (stories.length === 0) {
      storyContainer.innerHTML = '<p>Tidak ada story.</p>';
      return;
    }

    const initMap = () => {
      const map = L.map(mapContainer).setView([0, 0], 2);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(map);

      stories.forEach((story) => {
        if (story.lat && story.lon) {
          L.marker([story.lat, story.lon])
            .addTo(map)
            .bindPopup(`<strong>${story.name}</strong><br>${story.description}`);
        }
      });
    };

    if (mapContainer) {
      initMap();
    } else {
      requestAnimationFrame(() => {
        if (mapContainer) {
          initMap();
        }
      });
    }

    const storyHtml = stories.map((story) => {
      return `
        <article class="story-item">
          <img src="${story.photoUrl}" alt="Photo from ${story.name}" class="story-img" />
          <h2 class="story-title">${story.name}</h2>
          <p class="story-description">${story.description}</p>
          <time datetime="${story.createdAt}" class="story-date">
            ${new Date(story.createdAt).toLocaleString()}
          </time>
        </article>
      `;
    }).join('');

    if (storyContainer) {
      storyContainer.innerHTML = storyHtml;
    } else {
      requestAnimationFrame(() => {
        if (storyContainer) {
          storyContainer.innerHTML = storyHtml;
        }
      });
    }
  }
}
