export default class AboutPresenter {
    static async init() {
    }
  }
  